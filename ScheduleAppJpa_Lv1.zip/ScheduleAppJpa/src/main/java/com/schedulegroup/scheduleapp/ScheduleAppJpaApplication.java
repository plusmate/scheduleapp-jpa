package com.schedulegroup.scheduleapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ScheduleAppJpaApplication {

    public static void main(String[] args) {
        SpringApplication.run(ScheduleAppJpaApplication.class, args);
    }

}
